from .generator import generate_schema

__version__ = '0.1.0'